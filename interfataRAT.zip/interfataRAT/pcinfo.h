#ifndef PCINFO_H
#define PCINFO_H

#include <QDialog>

namespace Ui {
class pcInfo;
}

class pcInfo : public QDialog
{
    Q_OBJECT

public:
    explicit pcInfo(QWidget *parent = nullptr);
    ~pcInfo();

private:
    Ui::pcInfo *ui;
};

#endif // PCINFO_H
