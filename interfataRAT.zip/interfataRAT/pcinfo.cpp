#include "pcinfo.h"
#include "ui_pcinfo.h"

pcInfo::pcInfo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::pcInfo)
{
    ui->setupUi(this);
}

pcInfo::~pcInfo()
{
    delete ui;
}
